import './style.css';

const app = document.querySelector('#app');
const KEY = 'eduscore_android_test_note';

app.innerHTML = `
  <main class="shell">
    <div class="brand-mark">E</div>
    <p class="eyebrow">ANDROID INSTALLATION TEST</p>
    <h1>EduScore</h1>
    <p class="subtitle">Offline Manager · Test Edition</p>
    <div class="status"><span class="dot"></span><span id="network">Checking connection…</span></div>

    <section class="card">
      <h2>Installation successful</h2>
      <p>If you can see this screen inside the installed Android app, the test APK is running.</p>
      <label for="note">Test local saving</label>
      <textarea id="note" rows="4" placeholder="Type a short note. It should remain here after closing and reopening the app."></textarea>
      <button id="save">Save on this device</button>
      <p id="saved" class="hint" aria-live="polite"></p>
    </section>

    <section class="card secondary">
      <h2>What this test proves</h2>
      <ul>
        <li>The web project can be packaged as an Android APK.</li>
        <li>The app can open without Google AI Studio.</li>
        <li>Basic information can be saved locally on this device.</li>
      </ul>
      <p class="warning">This is only a packaging test. It is not the full school management system and does not connect to Firebase.</p>
    </section>
    <footer>Model Junior Secondary School Kofar Arewa · EduScore test build</footer>
  </main>
`;

const note = document.querySelector('#note');
const saved = document.querySelector('#saved');
note.value = localStorage.getItem(KEY) || '';
document.querySelector('#save').addEventListener('click', () => {
  localStorage.setItem(KEY, note.value);
  saved.textContent = 'Saved on this device.';
});
function updateNetwork() {
  const online = navigator.onLine;
  document.querySelector('#network').textContent = online ? 'Internet connection available' : 'Offline mode';
  document.querySelector('.status').classList.toggle('offline', !online);
}
window.addEventListener('online', updateNetwork);
window.addEventListener('offline', updateNetwork);
updateNetwork();
